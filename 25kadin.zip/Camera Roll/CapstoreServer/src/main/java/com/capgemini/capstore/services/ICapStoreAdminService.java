package com.capgemini.capstore.services;

public interface ICapStoreAdminService {
	
}
