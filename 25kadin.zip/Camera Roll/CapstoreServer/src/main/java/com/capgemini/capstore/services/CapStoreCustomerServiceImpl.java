package com.capgemini.capstore.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Admin;
import com.capgemini.capstore.beans.Cart;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.MerchantFeedback;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.ProductFeedback;
import com.capgemini.capstore.beans.User;
import com.capgemini.capstore.beans.Wishlist;
import com.capgemini.capstore.dao.ICapStoreAdminDAO;
import com.capgemini.capstore.dao.ICapStoreCartDAO;
import com.capgemini.capstore.dao.ICapStoreCustomerDAO;
import com.capgemini.capstore.dao.ICapStoreMerchantDAO;
import com.capgemini.capstore.dao.ICapStoreMerchantFeedbackDAO;
import com.capgemini.capstore.dao.ICapStoreOrderDAO;
import com.capgemini.capstore.dao.ICapStoreProductDAO;
import com.capgemini.capstore.dao.ICapStoreProductFeedbackDAO;
import com.capgemini.capstore.dao.ICapStoreUserDAO;
import com.capgemini.capstore.dao.ICapStoreWishlistDAO;
import com.capgemini.capstore.exceptions.CustomerNotFoundException;

@Service
public class CapStoreCustomerServiceImpl implements ICapStoreCustomerService {
	
	@Autowired
	ICapStoreUserDAO userDAO;

	@Autowired
	ICapStoreAdminDAO adminDAO;
	
	@Autowired
	ICapStoreProductDAO productDAO;

	@Autowired
	ICapStoreCartDAO cartDAO;

	@Autowired
	ICapStoreCustomerDAO customerDAO;

	@Autowired
	ICapStoreMerchantDAO merchantDAO;

	@Autowired
	ICapStoreOrderDAO customerOrderDAO;

	@Autowired
	ICapStoreWishlistDAO customerWishListDAO;

	@Autowired
	private ICapStoreProductFeedbackDAO capStoreFeedback;

	@Autowired
	private ICapStoreProductDAO capStoreProduct;

	@Autowired
	private ICapStoreCustomerDAO capStoreCustomer;

	@Autowired
	private ICapStoreMerchantFeedbackDAO merchantFeedback;

	@Override
	public List<Product> getAllProduct() {
		return productDAO.findAll();
	}

	@Override
	public Product getProduct(int productId) {
		return productDAO.findById(productId).orElse(null);
	}

	@Override
	public List<Cart> getCartItem(int customerId) {
		return cartDAO.findCartByCustomerId(customerId);
	}

	@Override
	public List<Cart> addProductToCart(int customerId, int productId, int merchantId, int quantity) {
		Product product = productDAO.findById(productId).orElse(null);
		Customer customer = customerDAO.findById(customerId).orElse(null);
		Merchant merchant = merchantDAO.findById(merchantId).orElse(null);
		Cart cart = new Cart();
		cart.setCustomer(customer);
		cart.setMerchant(merchant);
		cart.setId(1001);
		cart.setProduct(product);
		cart.setPromo(null);
		cart.setProductPrice(product.getProductPrice());
		cart.setQuantity(quantity);
		cart.setSoftDelete("A");
		cartDAO.save(cart);
		// System.out.println("\n\nService\n\n"+cartDAO.findByCustomer(customerDAO.findById(customerId).get()));
		return cartDAO.findByCustomer(customerDAO.findById(customerId).get());
	}

	@Override
	public void removeProductFromCart(int cartId) {
		cartDAO.deleteById(cartId);
	}

	@Override
	public List<Order> getOrders(int id) throws CustomerNotFoundException {
		List<Order> returnig = new ArrayList<Order>();
		if (!customerDAO.existsById(id))
			throw new CustomerNotFoundException("customer not found");
		else {
			List<Order> orders = customerOrderDAO.findAll();
			for (Order i : orders) {
				if (i.getCustomer().getCustomerId() == id)
					returnig.add(i);
			}
			return returnig;
		}
	}

	@Override
	public int getMerchantIdByProductId(int productId) {

		return merchantDAO.getMerchantId(productId);
	}

	@Override
	public List<String> getStatus(int id) throws CustomerNotFoundException {
		List<String> status = new ArrayList<>();
		if (!customerDAO.existsById(id))
			throw new CustomerNotFoundException("customer not found");
		else {
			List<Order> orders = customerOrderDAO.findAll();
			for (Order i : orders) {
				if (i.getCustomer().getCustomerId() == id)
					status.add(i.getDeliveryStatus());
			}
		}
		return status;
	}

	@Override
	public List<Wishlist> getWishlist(int id) throws CustomerNotFoundException {
		List<Wishlist> wishlist = new ArrayList<>();
		if (!customerDAO.existsById(id))
			throw new CustomerNotFoundException("customer not found");
		else {
			List<Wishlist> all = customerWishListDAO.findAll();
			for (Wishlist i : all) {
				if (i.getCustomer().getCustomerId() == id)
					wishlist.add(i);
			}
		}
		return wishlist;
	}

	@Override
	public int findCustomerIdByEmailId(String emailId) {
		User user = userDAO.findById(emailId).get();
		System.out.println(capStoreCustomer.findByCustomerEmail(user.getEmailId()).getCustomerId());
		return capStoreCustomer.findByCustomerEmail(user.getEmailId()).getCustomerId();
	}

	@Override
	public List<Cart> getCart(int customerId) {

		List<Cart> updated = new ArrayList<Cart>();
		List<Cart> cart = cartDAO.findByCustomer(customerDAO.findById(customerId).get());
		for (Cart car : cart) {
			if (car.getSoftDelete().equals("A")) {
				updated.add(car);
			}

		}
		return updated;
	}

	@Override
	public Wishlist addProductsToWishList(int customerId, int merchantId, int productId) {
		Customer customer = customerDAO.findById(customerId).get();
		Wishlist wishlist = new Wishlist();
		wishlist.setCustomer(customer);
		Product product = productDAO.findById(productId).orElse(null);
		wishlist.setProduct(product);
		Merchant merchant = merchantDAO.findById(merchantId).get();
		wishlist.setMerchant(merchant);
		customerWishListDAO.save(wishlist);
		return wishlist;
	}

	@Override
	public List<Wishlist> deleteProductsFromWishList(int customerId) throws CustomerNotFoundException {
		if (!customerDAO.existsById(customerId)) {
			throw new CustomerNotFoundException("customer not found");
		} else {
			List<Wishlist> all = customerWishListDAO.findAll();
			for (Wishlist i : all) {
				if (i.getCustomer().getCustomerId() == customerId) {
					Product prod = productDAO.findById(i.getProduct().getProductId()).get();
					Merchant merchant = merchantDAO.findById(i.getMerchant().getMerchantId()).get();
					Customer cust = customerDAO.findById(i.getCustomer().getCustomerId()).get();
					Cart cart = new Cart();
					cart.setCustomer(cust);
					cart.setProduct(prod);
					cart.setMerchant(merchant);
					cartDAO.save(cart);
					customerWishListDAO.deleteById(i.getId());
				}
			}
		}
		return null;
	}

	public MerchantFeedback setMerchantFeedback(MerchantFeedback feedback) {

		// entityManager.persist(feedback);
		merchantFeedback.save(feedback);

		return feedback;

	}

	public List<MerchantFeedback> getFinalMerchantFeedback() {
		List<MerchantFeedback> feedback = new ArrayList<MerchantFeedback>();
		feedback = merchantFeedback.findByStatus("R");
		// merchantFeedback.saveAll(feedback);
		return feedback;
	}

	public ProductFeedback setFeedback(ProductFeedback productFeedback) {

		// entityManager.persist(feedback);
		capStoreFeedback.save(productFeedback);

		return productFeedback;

	}

	public List<ProductFeedback> getAll(int product_Id) {

		// List<ProductFeedback> product_feedback = new
		// ArrayList<ProductFeedback>();

		List<ProductFeedback> product_feedback = capStoreFeedback
				.findByProduct(capStoreProduct.findById(product_Id).get());
		// List<ProductFeedback> prod = capStoreFeedback.findAll();
		return product_feedback;
	}

	public List<ProductFeedback> getProductFeedBack(int customerId) {
		List<ProductFeedback> productFeedBack;

		productFeedBack = capStoreFeedback.findByCustomer(capStoreCustomer.findById(customerId).get());

		return productFeedBack;
	}

	public ProductFeedback updateFeedback(int feedback_Id, ProductFeedback productFeedBack) {

		ProductFeedback productFeedBack_update;

		productFeedBack_update = capStoreFeedback.findById(feedback_Id);
		productFeedBack.setId(productFeedBack_update.getId());
		capStoreFeedback.save(productFeedBack);
		return productFeedBack;
	}

	public List<Product> getProductByBrandName(String productBrand) {
		return capStoreProduct.findByProductBrand(productBrand);
	}

	public List<Product> getProductByCategory(String category) {
		return capStoreProduct.findByProductCategory(category);
	}

	public List<Product> getProductByName(String productName) {
		return capStoreProduct.findByProductName(productName);
	}

	@Override
	public Customer findCustomerObjectEmailId(String emailId) {
		User user = userDAO.findById(emailId).get();
		System.out.println(user.getEmailId());
		Customer cust= capStoreCustomer.findByCustomerEmail(user.getEmailId());
		System.out.println(cust.getCustomerEmail());
		return cust;
	}

	@Override
	public ProductFeedback setFeedback(String feedback, int rating, int productId, int customerId) {
		Product product =capStoreProduct.findById(productId).get();
		Customer customer = customerDAO.findById(customerId).get();
		System.out.println("yahooooo: "+product.getProductName());
		System.out.println("yahooooo: "+customer.getCustomerName());
		ProductFeedback productFeedback = new ProductFeedback();
		productFeedback.setId(6001);
		productFeedback.setProduct(product);
		productFeedback.setProductFeedback(feedback);
		productFeedback.setRating(rating);
		productFeedback.setCustomer(customer);
		capStoreFeedback.save(productFeedback);
		return productFeedback;
	}

	@Override
	public Merchant findMerchantObjectEmailId(String emailId) {
		User user = userDAO.findById(emailId).get();
		System.out.println(user.getEmailId());
		Merchant cust= merchantDAO.findByMerchantEmail(user.getEmailId());
		System.out.println(cust.getMerchantEmail());
		return cust;

	}

	@Override
	public Admin findAdminObjectEmailId(String emailId) {
		User user = userDAO.findById(emailId).get();
		System.out.println(user.getEmailId());
		Admin cust= adminDAO.findByAdminEmail(user.getEmailId());
		System.out.println(cust.getAdminEmail());
		return cust;
	}

}
