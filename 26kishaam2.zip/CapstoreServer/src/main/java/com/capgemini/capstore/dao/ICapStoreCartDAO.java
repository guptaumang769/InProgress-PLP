package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Cart;
import com.capgemini.capstore.beans.Customer;
@Repository
public interface ICapStoreCartDAO extends JpaRepository<Cart, Integer> {
	
	@Query("SELECT c from Cart c WHERE c.customer.customerId=:customerId AND c.softDelete='A'")
	public List<Cart> findCartByCustomerId(@Param(value = "customerId") int customerId);

	public List<Cart> findByCustomer(Customer customer);
	
	
}
