package com.capgemini.capstore.exceptions;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class CapStoreExceptionHandler extends ResponseEntityExceptionHandler{

}
