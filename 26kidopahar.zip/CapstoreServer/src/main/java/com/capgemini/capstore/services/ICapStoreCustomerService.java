package com.capgemini.capstore.services;

import java.util.List;

import com.capgemini.capstore.beans.Admin;
import com.capgemini.capstore.beans.Cart;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.MerchantFeedback;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.ProductFeedback;
import com.capgemini.capstore.beans.Wishlist;
import com.capgemini.capstore.exceptions.CustomerNotFoundException;

public interface ICapStoreCustomerService {

	public List<Product> getAllProduct();

	public Product getProduct(int productId);

	public List<Cart> getCartItem(int customerId);

	public List<Cart> addProductToCart(int customerId, int productId, int merchantId, int quantity);

	public void removeProductFromCart(int cartId);

	public List<Order> getOrders(int id) throws CustomerNotFoundException, CustomerNotFoundException;

	public List<String> getStatus(int id) throws CustomerNotFoundException;

	public List<Wishlist> getWishlist(int id) throws CustomerNotFoundException;

	public int findCustomerIdByEmailId(String emailId);
	
	public Customer findCustomerObjectEmailId(String emailId);

	public List<Cart> getCart(int customerId);

	public Wishlist addProductsToWishList(int customerId, int merchantId, int productId);

	public List<Wishlist> deleteProductsFromWishList(int customerId) throws CustomerNotFoundException;

	public List<MerchantFeedback> getFinalMerchantFeedback();

	public List<ProductFeedback> getAll(int product_Id);

	public MerchantFeedback setMerchantFeedback(MerchantFeedback merchantFeedBack);


	public ProductFeedback setFeedback(String feedback, int rating, int productId, int customerId);

	public Merchant findMerchantObjectEmailId(String emailId);

	public Admin findAdminObjectEmailId(String emailId);

	public Admin getAdmin();

}
