package com.dev.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dev.model.Invoice;

@Controller
@RequestMapping("/products")
public class InvoiceController {
	
	private Invoice product;
	Integer prodId;
	String name;
	Integer quantity;
	Double price;
	Integer prodDiscount;
	Double calc=0.0;
	Double totalPrice=0.0;
	String paymentStat;
	Scanner sc;
	
	@RequestMapping("/show")
	public String showProduct(Model model) {
		List<Invoice> cart_product= new ArrayList<Invoice>();
		for(int i=0;i<10;i++) {
			System.out.println("Enter Product Id: ");
			prodId=101;
			System.out.println("Enter Product Name: ");
			name="iPhone";
			System.out.println("Enter Product Quantity: ");
			quantity=2;
			System.out.println("Enter Product Price: ");
			price=15000.0;
			System.out.println("Enter Product Discount: ");
			prodDiscount=10;
			calc=(price-((price)/10))*quantity;
			totalPrice +=calc;
			product=new Invoice(prodId, name, quantity, price, prodDiscount);
			cart_product.add(product);
		}
		paymentStat="Pending";
		model.addAttribute("p", cart_product);
		model.addAttribute("q", totalPrice);
		model.addAttribute("r", paymentStat);
		return "show-product";// Logical View Name
	}
}
