package com.capgemini.capstore.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Cart;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.MerchantFeedback;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.ProductFeedback;
import com.capgemini.capstore.beans.User;
import com.capgemini.capstore.beans.Wishlist;
import com.capgemini.capstore.exceptions.CustomerNotFoundException;
import com.capgemini.capstore.services.ICapStoreAdminService;
import com.capgemini.capstore.services.ICapStoreCommonService;
import com.capgemini.capstore.services.ICapStoreCustomerService;
import com.capgemini.capstore.services.ICapStoreMerchantService;

@RestController
public class URIController {

	@Autowired
	ICapStoreCommonService commonService;

	@Autowired
	ICapStoreAdminService adminService;

	@Autowired
	ICapStoreMerchantService merchantService;

	@Autowired
	ICapStoreCustomerService customerService;

	@RequestMapping(value = "/logIn", method = RequestMethod.POST)
	public String logIn(@RequestBody User user, HttpServletRequest request) {
		
		boolean result = false;
		try {
			
			result = commonService.ValidateLogIn(user);
			System.out.println("Result"+result);
			if(result) {
							
				if (user.getRole().equals("ADMIN")) {
					
					return "Admin";
					
				}
				if (user.getRole().equals("MERCHANT")) {
									
					return "MerchantHome";				
									
				}
				if (user.getRole().equals("CUSTOMER")) {
					
					return "HomeCustomer";
					
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		// set error msg
		return "Home";
	}
	
	@RequestMapping(value = "/logOut", method = RequestMethod.GET)
	public String logOut(HttpServletRequest request) {
		request.getSession().invalidate();
		return "indexPage";
	}
	
	@RequestMapping(value = "/forgotPassword", method = RequestMethod.POST)
	public String forgotPassword(@RequestBody User user, HttpServletRequest request) {
		User result = null;
		if ((result = commonService.isValidEmail(user.getEmailId())) != null) {
			if (user.getSecurityQuestion().equals(result.getSecurityQuestion())
					&& user.getSecurityAnswer().equals(result.getSecurityAnswer())) {
				return "ForgotPasswordConfirmation";
			}
		}
		return "ForgotPassword";
	}

	@RequestMapping(value = "/passwordChangePage", method = RequestMethod.POST)
	public String passwordChangePage(@RequestBody User user, HttpServletRequest request) {
		commonService.updatePassword(user.getEmailId(), user.getPassword());
		return "Home";
	}

	@RequestMapping(value = "/changePassword/{oldPassword}/{newPassword}", method = RequestMethod.PUT)
	public String changePassword(@PathVariable String oldPassword, @PathVariable String newPassword,
			HttpServletRequest request) {
		HttpSession session = request.getSession();
		if (session == null) {
			return "logIn page WIth Msg you need to log In first";
		}
		if (commonService.changePassword((String) session.getAttribute("userId"), oldPassword, newPassword)) {
			return "passwordChangeSuccessfully";
		}
		return "changePasswordwithErrorPage";
	}

	@RequestMapping(value = "/signUp", method = RequestMethod.POST)
	public String signUp(@Valid @RequestBody User user) {
		System.out.println("hello");
		System.out.println(user);
		if (commonService.ValidateUserDetails(user)) {
			if (user.getRole().equalsIgnoreCase("CUSTOMER"))
				return "CustomerSignUp";
			if (user.getRole().equalsIgnoreCase("MERCHANT"))
				return "MerchantSignUp";
		}
		// set error msg details are incorrect
		return "ask";
	}

	@RequestMapping(value = "/registerMerchant", method = RequestMethod.POST)
	public String finalRegistrationForMerchant(@RequestBody Merchant merchant) {
		merchant.setMerchantRating(1);
		merchant.setProducts(new ArrayList<Product>());
		System.out.println(merchant);
		merchantService.registerMerchant(merchant);
		return "Login";
	}

	@RequestMapping(value = "/registerCustomer", method = RequestMethod.POST)
	public String finalRegistrationForCustomer(@RequestBody Customer customer) {
		System.out.println(customer);
		merchantService.registerCustomer(customer);
		return "Login";
	}

	@RequestMapping(value = "/getCustomerId", method = RequestMethod.POST)
	public int getCustomerId(@RequestBody User user) {
		return customerService.findCustomerIdByEmailId(user.getEmailId());
	}
	
	@RequestMapping(value = "/getCustomerObject", method = RequestMethod.POST)
	public Customer getCustomerObject(@RequestBody User user) {
		return customerService.findCustomerObjectEmailId(user.getEmailId());
	}

	@RequestMapping(value = "/getMerchantObject", method = RequestMethod.POST)
	public Merchant getMerchantObject(@RequestBody User user) {
		return customerService.findMerchantObjectEmailId(user.getEmailId());
	}
	@RequestMapping(value = "/showAllProduct", method = RequestMethod.GET)
	public List<Product> showAllProduct() {
		List<Product> products = customerService.getAllProduct();
		return products;
	}

	@RequestMapping(value = "/showProduct/{productId}", method = RequestMethod.GET)
	public Product showProduct(@PathVariable int productId) {
		Product product = customerService.getProduct(productId);
		return product;
	}

	@RequestMapping(value = "/displayCart/{productId}/{customerId}/{merchantId}/{quantity}", method = RequestMethod.GET)
	public List<Cart> addProductToCart(@PathVariable int productId, @PathVariable int customerId,
			@PathVariable int merchantId, @PathVariable int quantity) {
		return customerService.addProductToCart(customerId, productId, merchantId, quantity);
	}

	@RequestMapping(value = "/removeProductFromCart/{cartId}", method = RequestMethod.GET)
	public void removeProductFromCart(@PathVariable int cartId) {
		// System.out.println("sERVICE CART ID: "+cartId);
		customerService.removeProductFromCart(cartId);
	}

	@RequestMapping(value = "/getAllCart/{customerId}", method = RequestMethod.GET)
	public List<Cart> getCart(@PathVariable int customerId) {
		return customerService.getCart(customerId);
	}

	@RequestMapping(value = "/viewOrders/{id}", method = RequestMethod.GET)
	public List<Order> viewOrders(@PathVariable int id) throws CustomerNotFoundException {
		return customerService.getOrders(id);
	}

	@RequestMapping(value = "/deliveryStatus/{id}", method = RequestMethod.GET)
	public List<String> status(@PathVariable int id) throws CustomerNotFoundException {
		return customerService.getStatus(id);
	}

	@RequestMapping(value = "/getWishList/{id}", method = RequestMethod.GET)
	public List<Wishlist> WishList(@PathVariable int id) throws CustomerNotFoundException {
		return customerService.getWishlist(id);
	}

	@PostMapping("/addProductToWishList/{custId}/{merchId}/{productId}")
	public Wishlist addProductToWishlist(@PathVariable("custId") Integer custId,
			@PathVariable("merchId") Integer merchId, @PathVariable int productId) {
		Wishlist wishlist = customerService.addProductsToWishList(custId, merchId, productId);
		return wishlist;

	}

	@GetMapping("/deleteFromWishlist/{customerId}")
	public List<Wishlist> deleteWishlist(@PathVariable int customerId) throws CustomerNotFoundException {
		return customerService.deleteProductsFromWishList(customerId);
	}
	
	@RequestMapping(value = "/getMerchantId/{productId}", method = RequestMethod.GET)
	public int getMerchantId(@PathVariable int productId)  {
		return customerService.getMerchantIdByProductId(productId);
	}

	
	@RequestMapping(value="/addFeedback/{feedback}/{rating}/{productId}/{customerId}",method=RequestMethod.GET)
	public ProductFeedback setProductFeedback(@PathVariable String feedback, @PathVariable int rating,@PathVariable int productId, @PathVariable int merchantId, @PathVariable int customerId )
	{
		return customerService.setFeedback(feedback,rating, productId, customerId);
	}
	
	@RequestMapping(value="/getAll/{productId}",  method = RequestMethod.GET)
	public List<ProductFeedback> showAllProductFeedback(@PathVariable int productId)
	{
		return customerService.getAll(productId);
	}
	
	@RequestMapping(value="/addMerchantFeedback",method=RequestMethod.POST)
	public MerchantFeedback setProductFeedback(@RequestBody MerchantFeedback merchantFeedBack)
	{
		return customerService.setMerchantFeedback(merchantFeedBack);
	}
	
	
	@RequestMapping(value="/getAllMerchant",  method = RequestMethod.GET)
	public List<MerchantFeedback> showMerchantFeedback()
	{
		return customerService.getFinalMerchantFeedback();
	}
	
	
}
